package work05;

public interface IVehicleBiz {
	
	public Vehicle[] vehicleList();
	public void vehicleMove();
	public void vehicleAddFuel();
}
